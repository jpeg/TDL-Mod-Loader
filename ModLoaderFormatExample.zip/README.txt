Mod Loader Format Example
Version 0.3

Created by PEGelite
---------------------------------------------------------------------------------------

This is an example of an installable mod for the TDL Mod Loader. DO NOT RUN THE GAME WITH THIS FAKE MOD ENABLED.


Contents:

0. Credits
1. Installation
2. System Requirements
3. Known Issues
4. Disclaimer
5. Contact
6. Distribution & Commercial use
7. Third party use
8. Change Log


0 - Credits

PEGelite
TehFrederick

Special thanks to the following people:

Sandswept Studios for their hard work developing The Dead Linger


1 - Installation

Use the mod loader to install.


2 - System Requirements

None beyond the base requirements of the game.


3 - Known Issues

DO NOT RUN THE GAME WITH THE MOD ENABLED OR THE FAKE PLUGIN WILL MAKE BAD THINGS HAPPEN.


4 - Disclaimer

This mod is not made by or associated with Sandswept Studios.

All credit for The Dead Linger game, trademarks, and the base scripts modified for the mods go to Sandswept Studios.

I am not responsible for any damage or loss of data caused by the installation or use of this mod.


5 - Contact

Contact me via private message on http://sandswept.net/forums (username "PEGelite") or by email at pegelite@gmail.com with subject line "TDL Basic GUI Mod".

Please include the mod version number in your message.


6 - Distribution & Commercial use

If you are interested in hosting this file or distributing it in any manner then please contact me.

Hosting, or any other form of distribution is hereby forbidden without prior written permission.


7 - Third party use

Please use this format so you will be compatible with the mod loader. Feel free to copy any of the files included.


8 - Change Log

0.3 Changed to XML config file
    Added modes and options
0.2 Added icon and description
0.1 Initial release